package university

class Student {
    String name
    String email
    Integer age

    static hasMany = [enrollments: Enrollment]

    static constraints = {
        name blank: false
        email email: true, unique: true
        age min: 16, max: 100
    }

    String toString() {
        return name
    }

}