package university

class Enrollment {

    Student student
    Course course
    Date enrollmentDate = new Date()
    String grade

    static belongsTo = [student: Student, course: Course]

    static constraints = {
        student nullable: false
        course nullable: false
        enrollmentDate nullable: false
        grade nullable: true, inList: ['A', 'B', 'C', 'D', 'F']  // enable the null
    }

    String toString() {
        def studentName = student?.name ?: "Unknown Student"
        def courseTitle = course?.title ?: "Unknown Course"
        def gradeStr = grade ? " (Grade: $grade)" : ""
        return "${studentName} enrolled in ${courseTitle}${gradeStr}"
    }
}
