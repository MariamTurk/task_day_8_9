package university

class Course {

    String title
    String code

    static hasMany = [enrollments: Enrollment]

    static constraints = {
        title blank: false, unique: true
        code blank: false, unique: true, matches: "[A-Z]{3}[0-9]{3}"
    }

    String toString() {
        return "$title ($code)"
    }

}
