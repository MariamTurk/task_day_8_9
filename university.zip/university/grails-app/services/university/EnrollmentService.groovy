package university

import grails.gorm.transactions.Transactional

@Transactional
class EnrollmentService {

    GpaCalculatorService gpaCalculatorService

    /**
     * Saves a new enrollment if the student is not already enrolled in the course.
     * Throws an exception if a duplicate enrollment is attempted.
     */
    Enrollment save(Enrollment enrollment) {
        def existing = Enrollment.findByStudentAndCourse(enrollment.student, enrollment.course)
        if (existing) {
            throw new IllegalArgumentException("This student is already enrolled in this course.")
        }
        return enrollment.save(flush: true)
    }

    BigDecimal calculateStudentGpa(Student student) {
        def grades = Enrollment.findAllByStudent(student)
                .collect { it.grade }
                .findAll { it != null }
        return gpaCalculatorService.calculateGpa(grades)
    }

    Enrollment get(Serializable id) {
        Enrollment.get(id)
    }

    List<Enrollment> list(Map args) {
        Enrollment.list(args)
    }

    Long count() {
        Enrollment.count()
    }

    void delete(Serializable id) {
        Enrollment.get(id)?.delete(flush: true)
    }
}
