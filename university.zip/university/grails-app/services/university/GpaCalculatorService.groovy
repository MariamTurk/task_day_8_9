package university

import grails.gorm.transactions.Transactional

@Transactional(readOnly = true) // there is no update just read the data
class GpaCalculatorService {


    BigDecimal calculateGpa(List<String> grades) {
        // check if there is a grad or not , if there is no garde make it 0
        if (!grades || grades.isEmpty()) return 0.0

        // this to convart the a,b,c ... to number from 0 to 4 by use the fun convertGradeToPoint
        def gradePoints = grades.collect { convertGradeToPoint(it) }
                // if there i null or garde not exist ignor it
                .findAll { it != null }

        if (gradePoints.isEmpty()) return 0.0

        // cal GPA
        //      sum of grades       number of grades   to make the number after . just 2
        //                          or the courses
        return (gradePoints.sum() / gradePoints.size()).setScale(2, BigDecimal.ROUND_HALF_UP)
    }

    private BigDecimal convertGradeToPoint(String grade) {
        switch(grade) {
            case 'A': return 4.0
            case 'B': return 3.0
            case 'C': return 2.0
            case 'D': return 1.0
            case 'F': return 0.0
            default: return null // Incomplete or unknown grade
        }
    }
}
