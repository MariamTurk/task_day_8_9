package university

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
