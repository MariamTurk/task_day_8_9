package university

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class GpaCalculatorServiceSpec extends Specification implements ServiceUnitTest<GpaCalculatorService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
