package university

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class EnrollmentSpec extends Specification implements DomainUnitTest<Enrollment> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
